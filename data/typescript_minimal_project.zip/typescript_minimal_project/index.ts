import { foo } from "./util";

export { foo as FOO };
