export let foo = 42;
